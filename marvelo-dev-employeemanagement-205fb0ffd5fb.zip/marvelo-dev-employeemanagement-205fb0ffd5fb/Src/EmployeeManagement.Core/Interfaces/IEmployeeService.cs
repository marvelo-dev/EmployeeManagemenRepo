﻿namespace EmployeeManagement.Core.Interfaces
{
    public interface IEmployeeService
    {
    }
}