﻿namespace EmployeeManagement.Core.Interfaces
{
    public interface IBenefitsService
    {
    }
}