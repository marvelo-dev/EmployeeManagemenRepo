﻿namespace EmployeeManagement.Core.Enums
{
    public enum Relationship
    {
        Son,
        Daughter,
        Spouse,
        Mother,
        Father,
        Grandfather,
        Grandmother,
        Other
    }
}